package forEach;
import java.util.*;

/*  for Each method is used to iterate over collections and steam in java
 * 
 * */
public class ForEcahMethodExample {

	public static void main(String[] args)
	{
		
		Map<Integer,String> map=new HashMap<>();
		map.put(1, "Pranav");
		map.put(2, "Prabhat");
		map.put(3, "Murari");
		map.put(4, "Kishan");
		map.put(5, "Shashi");
		
		map.forEach((key,value)->System.out.println(key+" "+value));
		System.out.println();
		map.forEach((key,value)->
		{
			if(key==4)
			{
				System.out.println(key+" "+value);
			}
		});
		System.out.println();
		map.forEach((key,value)->
		{
			if(value.equals("Shashi"))
			{
				System.out.println(key+" "+value);
			}
		});

	}

}
