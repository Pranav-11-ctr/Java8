package forEach;

import java.util.ArrayList;
import java.util.List;

public class ForEachMethodOnStream {

	public static void main(String[] args) {
		List<String> list=new ArrayList<>();
		list.add("Pranav");
		list.add("Prabhat");
		list.add("Murari");
		list.add("Kishan");
		list.add("Prem");
		list.add("Pankaj");
		
		list.stream().filter(name->name.startsWith("P")).forEach(str->System.out.println(str));

	}

}
