package stream;

import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

class Jodi
{
	String bf;
	String gf;
	public Jodi(String bf, String gf) {
		super();
		this.bf = bf;
		this.gf = gf;
	}
	
}




public class ConvertListOfStringToHashMap {

	public static void main(String[] args) {
		List<Jodi> list = List.of(new Jodi("Pranav","Mysore"),new Jodi("Sovick","Vidya"),new Jodi("Rishi","Ritwika"),new Jodi("Prem","Ankita"),new Jodi("Subo","Ankita"));
		
		 Map<String,String> map = list.stream().collect(Collectors.toMap(l->l.bf, l->l.gf));
		
		 for(Entry<String,String> e:map.entrySet())
		 {
			 System.out.println("bf "+e.getKey()+"\t"+"gf "+ e.getValue());
		 }
		
		
		
		
		
//		List<String> list=List.of("Pranav","Sai Harini","Rishi","prem");
//		Map<String,Integer> map = list.stream().collect(Collectors.toMap(str->str, str->str.length()));
//		System.out.println(map);

	}

}
