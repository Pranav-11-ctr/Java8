package stream;

import java.util.List;
import java.util.stream.Collectors;

public class FilterNameWhoseNameStartS {

	public static void main(String[] args) {
		
		List<String> list = List.of("Sai Harini","Shashi","Sovick","Pranav","Murari");
		
		List<String> list2 = list.stream().filter(s->s.startsWith("S")).collect(Collectors.toList());
		System.out.println(list2);

	}

}
