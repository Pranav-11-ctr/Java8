package stream;

import java.util.ArrayList;
import java.util.List;

public class StreamEx2WithFilter {

	public static void main(String[] args) {
		List<String> list=new ArrayList<>();
		list.add("Pranav Kumar");
		list.add("Pranav");
		list.add("Pran");
		list.add("Pranav1 Kumar");
		list.add("Pranr");
		
		System.out.println(list.stream().filter(name->name.length()<=6).count());
		

	}

}
