package stream;

import java.util.List;
import java.util.stream.Collectors;

public class SomeFunctionsOfStream {

	public static void main(String[] args) {
		//filter(Predicate)
		  //Predicate means boolean types function
		  //like e->e%2==0
		//in this whichever elements return true only those value return 
		List<String> list = List.of("Aman","Ankur","Pranav");
		List<String> list2 = list.stream().filter(e->e.startsWith("A")).collect(Collectors.toList());
		System.out.println(list2);
		
		
		
		//map(function)
		  //i.e. it return value for each element
		
		List<Integer> list3 = List.of(11,12,13,14,15,16,17,18,19);
		List<Integer> list4 = list3.stream().map(e->e*e).collect(Collectors.toList());
		System.out.println(list4);
		System.out.println(list3);

	}

}
