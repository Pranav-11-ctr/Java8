package function;

import java.util.function.Function;

/*
 * input:- perform operation-----> output
 *it is used to perform operation
 *ex 4---> square operation  --> 16
 *
 *It is a functional interface
 *
 *interface Function<T,R>
 *{
 *  public R apply(T t);
 *} 
 *where T is input type and R is return type
 * 
 * */

public class FunctionInterfaceIntro {

	public static void main(String[] args) {
		
		
//		Function<Integer,Integer> f=i->i*i;
//		System.out.println(f.apply(4));
//		System.out.println(f.apply(6));
		
		
		Function<String,Integer> f1=s->s.length();
		System.out.println(f1.apply("Pranav Kumar"));
		

	}

}
