package function;

import java.util.function.Function;

class Student
{
	String name;
	int marks;
	
	
	public Student(String name, int marks) {
		super();
		this.name = name;
		this.marks = marks;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getMarks() {
		return marks;
	}
	public void setMarks(int marks) {
		this.marks = marks;
	}
	
}

public class FunctionEx1 {

	public static void main(String[] args) {
		Function<Student,String> f=s->
		{
			int mark=s.marks;
			String grade="";
			if(mark>=80)grade="A[Distinction]";
			else if(mark>=50) grade="B[FirstClass]";
			else if(mark>=35 )grade="pass";
			else grade="Fail";
			return grade;
			
		};
		Student[] st= {new Student("Pranav",45),new Student("Mysore",100),new Student("Murari", 79)};

		for(Student s:st)
		{
			System.out.println(s.name +" "+f.apply(s));
		}
	}

}
