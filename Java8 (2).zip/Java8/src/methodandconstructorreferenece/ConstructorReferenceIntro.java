package methodandconstructorreferenece;


/*
 * Constructor reference :- When functional interface method return an object ,then we can go for constructor reference
 * */

class Sample
{
	Sample()
	{
		System.out.println("Inside sample class ");
	}
}
interface Interf2
{
	public Sample get();
}

public class ConstructorReferenceIntro {

	public static void main(String[] args) {
		Interf2 inf1=Sample::new;
		Sample s=inf1.get();//Here ,interface get method refers sample class constructor
		

	}

}
