package methodandconstructorreferenece;


//Lambda Expression ----->(alternating syntax)-->Method Reference
//constructor reference  -->it is used to reference purpose

//use double colon operator i.e. ::

public class MethodAndConstructorEx1 {

	public static void main(String[] args) {


	}

}
