package methodandconstructorreferenece;

interface Interf
{
	public int add(int a,int b);
}

public class MethodRefenceEx2 {
	
	public int sum(int a,int b)
	{
		return a+b;
	}

	public static void main(String[] args) {
		
		Interf inf=(a,b)->
		{
			return a+b;
		};
		System.out.println(inf.add(20,30));
		
		
		MethodRefenceEx2 ex1=new MethodRefenceEx2();
		Interf inf1=ex1::sum;
		System.out.println(inf1.add(12,13));


	}

}
