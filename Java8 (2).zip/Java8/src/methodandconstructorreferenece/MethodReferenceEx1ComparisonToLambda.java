package methodandconstructorreferenece;

public class MethodReferenceEx1ComparisonToLambda {
	
	//method which is used in method reference
	public static void m1()
	{
		for(int i=0;i<10;i++)
		{
			System.out.println(i+" child thread ");
		}
	}

	public static void main(String[] args) {

		//using lambda expresion
		Runnable r=()->
		{
			for(int i=0;i<10;i++)
			{
				System.out.println("Child Thread "+i);
			}
		};
		Thread t=new Thread(r);
		t.start();
		for(int i=0;i<5;i++)
		{
			System.out.println("Main method "+i);
		}
		
		
		
		//Using method reference
//		Runnable r=MethodReferenceEx1ComparisonToLambda::m1;
//		Thread t=new Thread(r);
//		t.start();
//		for(int i=0;i<5;i++)
//		{
//			System.out.println("Main method "+i);
//		}
		
		

	}

}
