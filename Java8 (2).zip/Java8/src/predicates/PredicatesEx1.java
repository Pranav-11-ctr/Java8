package predicates;

import java.util.function.Predicate;

/*
 * Predicates :- It is a function with a single argument and returns boolean value
 * 
 * It is used for conditional check
 * It is a  functional interface having method 
 * public abstract boolean test(T t)
 * 
 * 
 * interface Predicate<T>
 * {
 *   public boolean test(T t);
 * }
 * 
 * 
 * 
 * Ex :- Functional Interface contains only one method i.e. test()
 * */
public class PredicatesEx1 {

	public static void main(String[] args) {
		
//		Predicate<Integer> p=i-> i>10;
//		System.out.println(p.test(34));
//		System.out.println(p.test(8));
		
		String[] str= {"Nag","Chiranjeevi","Sunny","Katrina"};
		Predicate<String> p=s->s.length()>5;
		for(String s:str)
		{
			if(p.test(s))
			{
				System.out.println(s);
			}
		}

	}

}
