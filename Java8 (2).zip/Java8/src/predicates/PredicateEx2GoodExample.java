package predicates;
/*
 * It's possible to join predicate into single predicate by using 
 * 1) and()  :-Logical and
 * 2)or()  :-Logical or
 * 3)negate() :- not
 * 
 * */
import java.util.function.Predicate;

public class PredicateEx2GoodExample {

	public static void main(String[] args) {
		
		int[] x= {0,5,10,15,20,25,30};
		Predicate<Integer> p1=i->i>10;
		Predicate<Integer> p2=i->i%2==0;
		System.out.println("The number greater than 10");
		m1(p1,x);
		System.out.println();
		System.out.println("Even number are");
		m1(p2,x);
		System.out.println();
		System.out.println("Number not greater tahn 10");
		m1(p1.negate(),x);
		System.out.println();
		System.out.println("Even and greater than 10");
		m1(p2.and(p1),x);
		System.out.println();
		System.out.println("Number greater tahn 10 or even");
		m1(p1.and(p2),x);

	}

	private static void m1(Predicate<Integer> p, int[] x) {
		for(int x1:x)
		{
			if(p.test(x1))
				System.out.print(x1+" ");
		}
		
	}

}
