package predicates;

import java.util.List;
import java.util.function.Predicate;

class Employee
{
	String name;
	double salary;
	public Employee(String name, double salary) {
		super();
		this.name = name;
		this.salary = salary;
	}
	
}

public class PredicateEx2 {

	public static void main(String[] args) {
		
		List<Employee> list = List.of(new Employee("Pranav",700000),new Employee("Prabhat",7000000),new Employee("Murari",500000),new Employee("Kishan",800000));
		Predicate<Employee> p=emp->emp.salary>500000;
		for(Employee em:list)
		{
			if(p.test(em))
				System.out.println(em.name+" "+em.salary);
		}

	}

}
