package consumer;

import java.util.function.Consumer;

/*
 * 
 * It is a functional interface
 * it doesn't return anything
 * 
 * mainly it is used to print
 * 
 * syntax
 * interface Consumer<T>
 * {
 *   public void accept(T t);
 * }
 * 
 * */

public class ConsumerInterfaceIntro {

	public static void main(String[] args) {
		
		Consumer<String> c=s->System.out.println(s);
		c.accept("Pranav Kumar");
		
		

	}

}
