package consumer;

import java.util.function.Consumer;

class Movie
{
	String name;
	
	public Movie(String name)
	{
		this.name=name;
	}
}

public class ConsumerExample {

	public static void main(String[] args) {
		Consumer<Movie> c=m->System.out.println(m.name);
		Movie m=new Movie("Hum dil de chuke sanam");
		c.accept(m);

	}

}
