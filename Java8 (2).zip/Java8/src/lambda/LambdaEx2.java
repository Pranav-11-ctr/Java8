package lambda;

interface FunctionalInterface1
{
	int method(int a,int b);
}
public class LambdaEx2 {

	public static void main(String[] args) {
		FunctionalInterface1 interf=(a,b)->a+b;
		System.out.println(interf.method(23, 890));

	}

}
