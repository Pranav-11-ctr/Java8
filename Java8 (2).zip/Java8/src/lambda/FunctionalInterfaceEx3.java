package lambda;

interface MyInterface
{
	int divide(int a,int b);
	//int add(int a,int b);
}
public class FunctionalInterfaceEx3 {

	public static void main(String[] args) {
		
//		MyInterface mi=(a,b)->a+b;
//		System.out.println(mi.add(23, 45));
		
		MyInterface mi=(a,b)->
		{
			if(b==0)
				return Integer.MIN_VALUE;
			else
				return a/b;
		};
		
		System.out.println(mi.divide(200,0));

	}

}
