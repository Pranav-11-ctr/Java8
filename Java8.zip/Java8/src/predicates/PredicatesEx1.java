package predicates;

import java.util.function.Predicate;

/*
 * Predicates :- It is a function with a single argument and returns boolean value
 * 
 * Ex :- Functional Interface contains only one method i.e. test()
 * */
public class PredicatesEx1 {

	public static void main(String[] args) {
		
		Predicate<Integer> p=i->i>10;
		System.out.println(p.test(34));
		System.out.println(p.test(8));

	}

}
