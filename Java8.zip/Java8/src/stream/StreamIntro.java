package stream;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/*
 * collection :-If we want to represent a group of individual objects as a single entity we should go for collection
 * 
 * stream:- If we want to process a group of objects we should go for streams
 * 
 * java.io.stream:- meant for processing of binary and character data with respect to file
 * 
 * 
 *We can process the  objects in the following two ways
 *1. Configuration  a)Filter
 *					b)Map
 *2.Processing
 *					a)processing by collect() method
 *					b)processing by count() method
 *                  c)processing by sorted() method
 *                  d)processing by min() and max() method
 *                  e)forEach() method
 *                  f)toArray() method()
 *                  g) Stream.of() method
 *                  
 *                  
 *    Example of Filter and Map
 * */
public class StreamIntro {

	public static void main(String[] args) {
		/*
		 * *FILTER
		We can configure filter to filter elements from the collection based on some boolean condition
		syntax:- public Stream filter(Predicate<T> t) can be boolean valued function or lambda function
		
		*/
		//with filter and processing by collect method
		ArrayList<Integer> list=new ArrayList<>();
		for(int i=0;i<=10;i++)
		{
			list.add(i);
		}
		List<Integer> list1 = list.stream().filter(x->x%2==0).collect(Collectors.toList());
		System.out.println(list1);
		
		
		
		
		
		
		/*
		 *MAP
		 *If we want to create a separate new object , for every object present in collection based on our requirement
		 *then we should go for map
		 *
		 *Syntax:- public Stream map(Function f) it can be lambda expression also
		 */
		
		ArrayList<String> list2=new ArrayList<>();
		list2.add("Murari Kumar");
		list2.add("Pranav Chau");
		list2.add("Prabhat Chaudhary");
		list2.add("Shashi Singh");
		list2.add("kishan Sah");
		
		List<String> list3 = list2.stream().map(s->s.toUpperCase()).collect(Collectors.toList());
		System.out.println(list3);
		
		//processing by Count method 
		//syntax;- public long count
		System.out.println(list3.stream().filter(s->s.length()>10).count());
		
		//processing by sorted method
		//syntax:- sorted():- natural sorting order
		//         sorted(Comparator c)
		List<String> list4 = list2.stream().sorted().collect(Collectors.toList());
		System.out.println(list4);
		List<String> list5 = list2.stream().sorted((s1,s2)->s2.compareTo(s1)).collect(Collectors.toList());
		System.out.println(list5);
		
		//processing by min() and max()
		//syntax:- min(comparator c) , max(Comparator c) returns min or max according to comparator 
		String string1 = list2.stream().min((s1,s2)->s1.compareTo(s2)).get();
		System.out.println(string1);
		String string2 = list2.stream().max((s1,s2)->s1.compareTo(s2)).get();
		System.out.println(string2);
		
		//forEach():- the method take lambda expression
		//syntax:-l.stream.forEach(s->sop(s))
		list5.stream().forEach(s->System.out.println(s));
		
		//.toArray()
		//:- We can use toArray() method to copy elements present in stream into specified array
		
		String[] strList=list5.stream().toArray(String[] ::new);
		for(String s:strList)
		{
			System.out.print(s+" ");
		}
		System.out.println();

		//Stream.of()
		//we can also apply stream for group of values and for arrays
		Stream s=Stream.of(9,99,999,9999);
		s.forEach(s1->System.out.print(s1+" "));
		System.out.println();
		
		Integer[] arr= {10,23,45};
		Stream s1=Stream.of(arr);
		s1.forEach(s2->System.out.print(s2+" "));
	}

}
