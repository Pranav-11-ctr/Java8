package stream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

//to open function in ecllipse = fn+f3

//Stream api is used at collection process or group of object

public class StreamEx1 {

	public static void main(String[] args) {
		
		List<Integer> list = List.of(2,4,50,21,22,67);
		System.out.println(list+"\n");
		
		List<Integer> listEven=new ArrayList<>();
		
		
//		for(int i:list)
//		{
//			if(i%2==0)
//			{
//				listEven.add(i);
//			}
//		}
//		System.out.println(listEven);
//		
		Stream<Integer> stream = list.stream();
		List<Integer> list2 = stream.filter(i->i%2==0).collect(Collectors.toList());
		System.out.println(list2);
		
		List<Integer> listEven1=new ArrayList<>();
		Stream<Integer> stream1 = list.stream();
		
		List<Integer> list3 = stream1.filter(i->i>10).collect(Collectors.toList());
		System.out.println(list3);
		
		
		
		
		//Create Stream object
		
		//1.
		String names[]= {"Pranav","Prabhat","Murari"};
		Stream<String> stream2 = Stream.of(names);
		stream2.forEach(e->System.out.println(e));
		
		//2
		IntStream stream3 = Arrays.stream(new int[] {2,4,6,8});
		stream3.forEach(e->System.out.println(e+10));
		
		
		
		

	}

}
