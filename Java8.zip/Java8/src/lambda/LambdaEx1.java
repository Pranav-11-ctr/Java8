package lambda;
//Lambda Expresssion is just an anonymous function.
//That means the function which doesn't have name,return type and access modifier

/*FUNCTIONAL INTERFACE:- If an interface contain only one abstract method such type of interface is called Functional interface
 * 
 * Ex:- Runnable -run()
 *      Comparable -compareTo()
 *      Comparator  -compare()
 * */

interface FunctionalInterface
{
	void method();
}
public class LambdaEx1 {

	public static void main(String[] args) {
		
		FunctionalInterface inf=()->System.out.println("Functional Interface Example");
		inf.method();
	}

}
